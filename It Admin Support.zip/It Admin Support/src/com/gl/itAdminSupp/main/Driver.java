package com.gl.itAdminSupp.main;

import java.util.Scanner;

import com.gl.itAdminSupp.services.GenerateEmail;
import com.gl.itAdminSupp.services.GeneratePassword;

public class Driver {
	public static Scanner sc = new Scanner(System.in);
	public static int num;
	public static String dept;
	public static GenerateEmail ge = new GenerateEmail();
	public static GeneratePassword gp=new GeneratePassword();
	public static String randomNum;

	public static void main(String[] args) {
		System.out.println("Press 1 for Technical");
		System.out.println("Press 2 for Admin");
		System.out.println("Press 3 for Human Resource");
		System.out.println("Press 4 for Legal");
		num = sc.nextInt();
		switch (num) {
		case 1:
			dept = "Technical";
			
			ge.getEmail("rajib", "deb", dept);
			randomNum=gp.randomNum();
			System.out.println(randomNum);
			break;
		case 2:
			dept = "Admin";

			ge.getEmail("rajib", "deb", dept);
			randomNum=gp.randomNum();
			System.out.println(randomNum);
			break;
		case 3:
			dept = "HumanResource";
			
			ge.getEmail("rajib", "deb", dept);
			randomNum=gp.randomNum();
			System.out.println(randomNum);
			break;

		case 4:
			dept = "Legal";
			
			ge.getEmail("rajib", "deb", dept);
			randomNum=gp.randomNum();
			System.out.println(randomNum);
			break;

		default:
			System.out.println("Please enter the correct input");

		}

	}

}
