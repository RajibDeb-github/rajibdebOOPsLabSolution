package com.gl.itAdminSupp.services;

import java.util.Random;

public class GeneratePassword {
	
	public String randomNum() {

	Random r = new Random();

	 char[] choices = ("abcdefghijklmnopqrstuvwxyz" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "01234567890" + "$#_@%&")
			.toCharArray();

	int len = 10;
	StringBuilder salt = new StringBuilder(len);for(
	int i = 0;i<len;++i)salt.append(choices[r.nextInt(choices.length)]);
	return salt.toString();

}
	}
