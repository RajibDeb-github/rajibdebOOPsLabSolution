package com.gl.itAdminSupp.services;

import com.gl.itAdminSupp.beans.Employee;

public class GenerateEmail {
   public void getEmail(String firstName, String lastName, String dept) {
	   Employee e=new Employee(firstName, lastName);
	   System.out.println("Employee email address is: "+firstName+lastName+"@"+dept+".company.com");
	   
   }
}
